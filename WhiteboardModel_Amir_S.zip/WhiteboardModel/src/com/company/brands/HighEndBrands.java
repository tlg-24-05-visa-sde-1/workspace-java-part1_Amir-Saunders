package com.company.brands;

public enum HighEndBrands {

    MEEPO,
    BACKFIRE,
    EXWAY,
    EVOLVE,
    ONSRA
}
